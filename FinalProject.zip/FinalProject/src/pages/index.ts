export { default as Login } from "./Login";
export { default as Products } from "./Products"
export { default as Categories } from "./Categories";
export { default as Color } from "./Colors";